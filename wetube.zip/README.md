#Wetube

/ -> home
/join
/login
/search

/users/:id -> profile
/users/logout
/users/edit 
/users/delete

/videos/:id -> watch video
/videos/:id/edit
/videos/:id/delete
/videos/upload
