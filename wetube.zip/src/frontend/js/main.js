import "../scss/style.scss";

console.log("hello");
